package com.cs3270assignments.CS3270A5;

public interface DialogFragListener {
    void resetGame();
}
